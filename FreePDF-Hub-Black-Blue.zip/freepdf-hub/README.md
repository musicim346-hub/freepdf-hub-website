# FreePDF Hub — website starter

## Files
- `index.html` — responsive website and browser-side tools
- `manifest.webmanifest` — installable web app metadata
- `sw.js` — basic same-origin cache for repeat visits

## Publish on Firebase Hosting (Android-friendly)
1. On your Android phone, open https://console.firebase.google.com/ and sign in.
2. Create/select a Firebase project, then open Hosting and choose Get started.
3. Firebase Hosting deployment normally requires the Firebase CLI. The CLI runs in a terminal on a computer or cloud development environment; the Firebase Console on Android does not provide a direct upload/deploy button for this folder.
4. Easiest Android route: upload these files to your existing GitHub repository using github.com in Chrome → repository → Add file → Upload files. Upload `index.html`, `manifest.webmanifest`, and `sw.js` to the repository root and commit.
5. For Firebase deployment, use a computer or cloud IDE with Node.js:
   - `npm install -g firebase-tools`
   - `firebase login`
   - `firebase init hosting` (choose the existing Firebase project and set public directory to this folder; configure as single-page app: No)
   - `firebase deploy`
6. Add `freepdf.sbs` in Firebase Hosting → Add custom domain, then follow the DNS records Firebase gives you at your domain provider. Do not guess or reuse old DNS records.
7. Wait for SSL certificate provisioning, then test `https://freepdf.sbs`.

## Important limitations
This is a functional starter, not a complete production clone of Smallpdf. Implemented browser-side actions include PDF merge, page extraction/removal, rotation, text extraction, PDF page rendering to PNG, image-to-PDF, text-to-PDF, text watermark/signature, page numbering, and basic image conversion/compression/crop/rotation. Some advertised items are deliberately labelled as not supported in this starter (password encryption/decryption, true PDF compression, Word-to-PDF). PDF-to-Word, PDF-to-Excel, OCR, full visual PDF editing, repair and secure password protection require additional libraries or a trusted backend and need separate implementation/testing.
External libraries load from CDNs; first load requires internet. The service worker caches the site shell only, not the PDF libraries or documents. Do not claim full offline operation.
Before public launch, add your actual contact address, privacy policy, terms, error reporting, accessibility testing, and test on real Android devices. Keep a backup of every original file.
